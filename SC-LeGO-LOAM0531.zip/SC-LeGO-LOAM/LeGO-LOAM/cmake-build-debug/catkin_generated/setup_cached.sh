#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables
export CMAKE_PREFIX_PATH="/home/hyq/ros_workspace/wc_sclegoloam/catkin_ws/src/SC-LeGO-LOAM/SC-LeGO-LOAM/LeGO-LOAM/cmake-build-debug/devel"
export LD_LIBRARY_PATH=""
export PKG_CONFIG_PATH=""
export PYTHONPATH=""

# modified environment variables